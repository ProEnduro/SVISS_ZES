PrimeFaces-Extensions Core
==========================

Core functionality for PrimeFaces Extensions
